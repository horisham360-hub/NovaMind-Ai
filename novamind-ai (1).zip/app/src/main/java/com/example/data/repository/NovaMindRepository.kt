package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.api.*
import com.example.data.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class NovaMindRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val threadDao = db.chatThreadDao()
    private val messageDao = db.chatMessageDao()
    private val imageDao = db.generatedImageDao()
    private val searchDao = db.searchHistoryDao()
    private val settingsDao = db.userSettingsDao()

    // --- DB Flow Expositions ---
    val allThreads: Flow<List<ChatThreadEntity>> = threadDao.getAllThreadsFlow()
    val allImages: Flow<List<GeneratedImageEntity>> = imageDao.getAllImagesFlow()
    val searchHistory: Flow<List<SearchHistoryEntity>> = searchDao.getAllSearchHistoryFlow()
    val userSettings: Flow<UserSettingsEntity?> = settingsDao.getSettingsFlow()

    fun getMessagesForThread(threadId: Int): Flow<List<ChatMessageEntity>> {
        return messageDao.getMessagesForThreadFlow(threadId)
    }

    suspend fun createThread(title: String): Int = withContext(Dispatchers.IO) {
        val thread = ChatThreadEntity(title = title)
        threadDao.insertThread(thread).toInt()
    }

    suspend fun deleteThread(threadId: Int) = withContext(Dispatchers.IO) {
        threadDao.deleteThreadById(threadId)
        messageDao.deleteMessagesForThread(threadId)
    }

    suspend fun saveMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        messageDao.insertMessage(message)
    }

    suspend fun saveSearch(query: String) = withContext(Dispatchers.IO) {
        if (query.isNotBlank()) {
            searchDao.insertSearchHistory(SearchHistoryEntity(query = query))
        }
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        searchDao.clearAllSearchHistory()
    }

    suspend fun saveSettings(settings: UserSettingsEntity) = withContext(Dispatchers.IO) {
        settingsDao.insertOrUpdateSettings(settings)
    }

    suspend fun getSettingsDirect(): UserSettingsEntity {
        return withContext(Dispatchers.IO) {
            settingsDao.getSettingsDirect() ?: UserSettingsEntity()
        }
    }

    // --- Gemini API Implementations ---

    private fun getApiKey(): String {
        val key = BuildConfig.GEMINI_API_KEY
        return if (key == "MY_GEMINI_API_KEY" || key.isBlank()) "" else key
    }

    suspend fun hasValidKey(): Boolean {
        return getApiKey().isNotEmpty()
    }

    private fun parseHttpException(e: retrofit2.HttpException): String {
        return try {
            val errorBody = e.response()?.errorBody()?.string()
            if (!errorBody.isNullOrBlank()) {
                val messageRegex = """"message"\s*:\s*"([^"]+)"""".toRegex()
                val match = messageRegex.find(errorBody)
                match?.groupValues?.get(1) ?: "HTTP ${e.code()}: ${e.message()}"
            } else {
                "HTTP ${e.code()}: ${e.message()}"
            }
        } catch (ex: Exception) {
            "HTTP ${e.code()}: ${e.message()}"
        }
    }

    /**
     * Call Gemini for Advanced Chat conversations. Exposes robust retry logic.
     */
    suspend fun generateChatResponse(
        prompt: String,
        history: List<ChatMessageEntity>,
        systemInstructions: String = "You are NovaMind AI, an ultra-premium, futuristic AI assistant created by Anas Ahmed. Speak eloquently, professionally, and respect the language chosen by the user."
    ): String = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isEmpty()) {
            return@withContext "API key not configured! Please configure the GEMINI_API_KEY inside the Secrets panel of AI Studio and restart."
        }

        // Build continuous chat memory contents array
        val contents = mutableListOf<Content>()
        
        // Map history to Gemini format (sending last 15 turns for performance + token economy)
        val visibleHistory = history.takeLast(15)
        var lastRole: String? = null
        visibleHistory.forEach { msg ->
            val currentRole = if (msg.role == "model") "model" else "user"
            if (currentRole != lastRole) {
                contents.add(Content(role = currentRole, parts = listOf(Part(text = msg.content))))
                lastRole = currentRole
            } else {
                if (contents.isNotEmpty()) {
                    val lastContent = contents.removeAt(contents.size - 1)
                    val updatedParts = lastContent.parts?.toMutableList() ?: mutableListOf()
                    updatedParts.add(Part(text = msg.content))
                    contents.add(lastContent.copy(parts = updatedParts))
                } else {
                    contents.add(Content(role = currentRole, parts = listOf(Part(text = msg.content))))
                    lastRole = currentRole
                }
            }
        }
        
        // Add current prompt
        if (lastRole == "user" && contents.isNotEmpty()) {
            val lastContent = contents.removeAt(contents.size - 1)
            val updatedParts = lastContent.parts?.toMutableList() ?: mutableListOf()
            updatedParts.add(Part(text = prompt))
            contents.add(lastContent.copy(parts = updatedParts))
        } else {
            contents.add(Content(role = "user", parts = listOf(Part(text = prompt))))
        }

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = Content(parts = listOf(Part(text = systemInstructions)))
        )

        val modelsToTry = listOf("gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-latest")
        var lastErrorMsg = "Unknown server communication timeout"
        for (modelName in modelsToTry) {
            try {
                val response = RetrofitClient.service.generateContent(
                    model = modelName,
                    apiKey = key,
                    request = request
                )
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (text != null) return@withContext text
            } catch (e: retrofit2.HttpException) {
                lastErrorMsg = parseHttpException(e)
            } catch (e: Exception) {
                lastErrorMsg = e.localizedMessage ?: "Connection error"
            }
        }
        "Generation failed: $lastErrorMsg. Please ensure your GEMINI_API_KEY inside the Secrets panel of AI Studio is configured correctly."
    }

    /**
     * Image Analysis & OCR.
     */
    suspend fun analyzeImageWithResponse(
        prompt: String,
        bitmap: Bitmap
    ): String = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isEmpty()) {
            return@withContext "API key not configured! Please configure the GEMINI_API_KEY inside the Secrets panel of AI Studio."
        }

        val base64Image = bitmap.toBase64()
        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            )
        )

        val modelsToTry = listOf("gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-latest")
        var lastErrorMsg = "Connection error"
        for (modelName in modelsToTry) {
            try {
                val response = RetrofitClient.service.generateContent(
                    model = modelName,
                    apiKey = key,
                    request = request
                )
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (text != null) return@withContext text
            } catch (e: retrofit2.HttpException) {
                lastErrorMsg = parseHttpException(e)
            } catch (e: Exception) {
                lastErrorMsg = e.localizedMessage ?: "Connection error"
            }
        }
        "Failed to analyze image: $lastErrorMsg. Please retry."
    }

    /**
     * Translates, refines, and improves any user image prompt to a detailed English prompt.
     */
    suspend fun optimizeImagePrompt(
        userPrompt: String,
        style: String
    ): String = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isEmpty()) {
            return@withContext userPrompt
        }

        val systemInstruction = """
            You are an AI image generation assistant.

            When a user asks to create an image in any language, never reject the request due to language differences. First understand, translate, and improve the user's prompt into a detailed English image-generation prompt.

            Rules:
            - Accept prompts in any language.
            - Automatically translate non-English prompts to English.
            - Expand short prompts into detailed professional image prompts.
            - If the prompt is unclear, make reasonable assumptions instead of returning "Invalid Prompt".
            - Preserve the user's original intent.
            - Return only the final optimized image prompt.
            - Never say "Invalid Prompt" unless the request violates safety policies.

            Example:
            User: "Ek futuristic city with flying cars"
            Output: "Ultra-realistic futuristic cyberpunk city at sunset, flying cars, neon lights, cinematic atmosphere, highly detailed, 8K quality, professional photography."
        """.trimIndent()

        val styleHint = if (style != "Original" && style.isNotBlank()) "Please ensure the generated optimized prompt is in a style of: $style." else ""

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = "User prompt: \"$userPrompt\"\n$styleHint")))),
            systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
        )

        val modelsToTry = listOf("gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-latest")
        for (modelName in modelsToTry) {
            try {
                val response = RetrofitClient.service.generateContent(
                    model = modelName,
                    apiKey = key,
                    request = request
                )
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                if (!text.isNullOrBlank()) {
                    var cleaned = text
                    if (cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
                        cleaned = cleaned.substring(1, cleaned.length - 1)
                    }
                    if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
                        cleaned = cleaned.substring(1, cleaned.length - 1)
                    }
                    if (cleaned.startsWith("Output:") || cleaned.startsWith("output:")) {
                        cleaned = cleaned.substring(7).trim()
                    }
                    if (cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
                        cleaned = cleaned.substring(1, cleaned.length - 1)
                    }
                    return@withContext cleaned
                }
            } catch (e: Exception) {
                // fall back to next model
            }
        }
        return@withContext userPrompt
    }

    /**
     * AI Image Generation (grafting standard prompt configurations for realistic, logos, etc.)
     */
    suspend fun generateImageFromPrompt(
        prompt: String,
        style: String // "Anime", "Realistic", "Logo / Branding", "Social Media", "Product Photography", "Original"
    ): String = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isEmpty()) {
            return@withContext "API_KEY_ERROR"
        }

        // Formulate professional modifier based on requested style
        val enhancedPrompt = when (style) {
            "Anime" -> "High quality modern anime illustration style, vivid color matching, detailed aesthetic lineart, $prompt"
            "Realistic" -> "Photorealistic DSLR high-end camera render, detailed lighting, volumetric reflections, crystal lens, $prompt"
            "Logo / Branding" -> "Modern vector logo, minimalist luxury tech emblem, branding geometry, high-contrast, professional, $prompt"
            "Social Media" -> "Trendy modern graphic design style post banner, typography layout framing, vibrant modern palette, $prompt"
            "Product Photography" -> "Luxury product studio shoot, professional light setup, clean background, 8k rendering catalog style, $prompt"
            else -> prompt
        }

        // The image model is gemini-2.5-flash-image
        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = enhancedPrompt)))),
            generationConfig = GenerationConfig(
                imageConfig = ImageConfig(aspectRatio = "1:1", imageSize = "1K"),
                responseModalities = listOf("TEXT", "IMAGE")
            )
        )

        val modelsToTry = listOf("gemini-2.5-flash-image", "gemini-3.1-flash-image-preview")
        var lastErrorMsg = "Connection error"
        for (modelName in modelsToTry) {
            try {
                val response = RetrofitClient.service.generateContent(
                    model = modelName,
                    apiKey = key,
                    request = request
                )
                val base64Img = response.candidates?.firstOrNull()?.content?.parts
                    ?.firstOrNull { it.inlineData != null }
                    ?.inlineData?.data

                if (base64Img != null) {
                    // Save to local database for persistent caching!
                    imageDao.insertImage(GeneratedImageEntity(prompt = prompt, base64Data = base64Img))
                    return@withContext base64Img
                }
            } catch (e: retrofit2.HttpException) {
                lastErrorMsg = parseHttpException(e)
            } catch (e: Exception) {
                lastErrorMsg = e.localizedMessage ?: "Connection error"
            }
        }
        "ERROR: $lastErrorMsg"
    }

    // Utility to convert Bitmap to Base64 String
    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }
}
