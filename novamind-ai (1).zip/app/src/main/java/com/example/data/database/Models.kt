package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_threads")
data class ChatThreadEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val threadId: Int,
    val role: String, // "user" or "model"
    val content: String,
    val imagePath: String? = null, // Path to local stored image if uploaded
    val fileType: String? = null, // "image", "text", "pdf", etc.
    val isVoice: Boolean = false,
    val voiceDurationSec: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val prompt: String,
    val base64Data: String, // Store image data directly as base64 for offline portability
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val id: Int = 1, // Only 1 settings row
    val username: String = "Anas Ahmed",
    val preferredLanguage: String = "English", // "English", "Hindi", "Urdu", "Arabic", "Marathi"
    val voiceOutputEnabled: Boolean = true,
    val voiceType: String = "Kore", // "Kore", "Puck" etc.
    val themeMode: String = "Dark", // "Dark", "Light", "System"
    val isSetupFinished: Boolean = false
)
