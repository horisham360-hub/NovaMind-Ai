package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.NovaMindViewModel
import java.io.InputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageAnalysisScreen(viewModel: NovaMindViewModel) {
    val context = LocalContext.current
    val analysisImage by viewModel.analysisImage.collectAsState()
    val fileText by viewModel.analysisFileText.collectAsState()
    val loading by viewModel.analysisLoading.collectAsState()
    val result by viewModel.analysisResult.collectAsState()

    var userQuestion by remember { mutableStateOf("Describe this image in detail, extract any visible text (OCR) and categorize keys.") }

    // Launcher to pick raw images from device gallery
    val imageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                viewModel.setAnalysisImage(bmp)
            } catch (e: Exception) {
                // handle error
            }
        }
    }

    // Mock PDF template contents to demonstrate File upload analysis
    val mockFiles = listOf(
        Pair("Marketing Plan.pdf", "NovaMind AI Launch Strategy: Q3 2026. Objective: Capture 20% of premium offline AI workspace audience. Budget: $450k. Primary leads: Anas Ahmed, CTO."),
        Pair("Model Architecture.txt", "class TransformerBlock(nn.Module):\n    def __init__(self, d_model, nhead):\n        val self.attention = MultiheadAttention(d_model, nhead)\n        val self.feedforward = FeedForward(d_model)"),
        Pair("Invoice #8392.pdf", "Invoice Date: 2026-06-15. Amount Due: $1,420.00 USD. Vendor: NeoTek Consulting. Deliverables: Jetpack Compose UI layout engineering templates.")
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "Analytical Core",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Upload images, files, or PDFs to perform OCR and object-based analysis",
                color = Color(0xFF00D2FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            // Dynamic Input Upload Selection Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Image gallery picker button
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                    border = BorderStroke(1.dp, if (analysisImage != null) Color(0xFF00D2FF) else Color(0x1F00D2FF)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { imageLauncher.launch("image/*") }
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "",
                            tint = if (analysisImage != null) Color(0xFF00D2FF) else Color.Gray,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (analysisImage != null) "Image Loaded" else "Select Image",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // File/PDF mockup switcher button
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                    border = BorderStroke(1.dp, if (fileText != null) Color(0xFFBF5AF2) else Color(0x1FBF5AF2)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            // Load first mock file by default
                            viewModel.setAnalysisFileText(mockFiles[0].second)
                        }
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = "",
                            tint = if (fileText != null) Color(0xFFBF5AF2) else Color.Gray,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (fileText != null) "PDF Loaded" else "Upload Doc / PDF",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Display of Active uploaded asset
            if (analysisImage != null) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Image(
                        bitmap = analysisImage!!.asImageBitmap(),
                        contentDescription = "Active upload analysis target",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else if (fileText != null) {
                // Show pre-loaded mock files horizontally to let the user select between them!
                Text(
                    text = "SELECT DOCUMENT TO INSPECT:",
                    color = Color(0xFF00D2FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    items(mockFiles) { fileInfo ->
                        val isActive = fileText == fileInfo.second
                        SuggestionChip(
                            onClick = { viewModel.setAnalysisFileText(fileInfo.second) },
                            label = { Text(fileInfo.first, fontSize = 11.sp, color = if (isActive) Color(0xFF03030F) else Color.White) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isActive) Color(0xFFBF5AF2) else Color(0xFF13112E)
                            )
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070518)),
                    border = BorderStroke(1.dp, Color(0x3FBF5AF2)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = "", tint = Color(0xFFBF5AF2), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Extracted File Text:", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = fileText!!,
                            color = Color.White,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Input Instructions Area
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0x1F00D2FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ANALYTICAL PROMPT / OCR INSTRUCTIONS",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    OutlinedTextField(
                        value = userQuestion,
                        onValueChange = { userQuestion = it },
                        placeholder = { Text("What would you like the model to analyze?", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFBF5AF2),
                            unfocusedBorderColor = Color(0x3F00D2FF),
                            focusedContainerColor = Color(0xFF070518),
                            unfocusedContainerColor = Color(0xFF070518)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.startAnalysis(userQuestion) },
                        enabled = (analysisImage != null || fileText != null) && !loading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFBF5AF2),
                            disabledContainerColor = Color(0xFFBF5AF2).copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Engaging Analytical Matrix...", color = Color.White, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = "", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Synthesize Analytical Report", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Output report area
            if (loading || result != null) {
                Text(
                    text = "ANALYTICAL REPORT OUTFLOW",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x3FBF5AF2))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = "",
                                tint = Color(0xFFBF5AF2),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Cognitive Synthesis Result",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (loading) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 12.dp)
                            ) {
                                CircularProgressIndicator(color = Color(0xFF00D2FF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Deciphering vectors...", color = Color.Gray, fontSize = 13.sp)
                            }
                        } else if (result != null) {
                            Text(
                                text = result!!,
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
