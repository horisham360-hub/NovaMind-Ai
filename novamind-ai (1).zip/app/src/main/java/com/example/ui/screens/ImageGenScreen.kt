package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.NovaMindViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageGenScreen(viewModel: NovaMindViewModel) {
    val prompt by viewModel.imageGenPrompt.collectAsState()
    val activeStyle by viewModel.imageGenStyle.collectAsState()
    val loading by viewModel.imageGenLoading.collectAsState()
    val base64Img by viewModel.generatedImageBase64.collectAsState()
    val galleryImages by viewModel.allGeneratedImages.collectAsState()

    // Expand image state
    var expandedBase64Img by remember { mutableStateOf<String?>(null) }

    val styles = listOf("Original", "Realistic", "Anime", "Logo / Branding", "Social Media", "Product Photography")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "Imaging Core",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Generate High Definition visuals using Gemini Imagery Core",
                color = Color(0xFF00D2FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            // Prompt Input Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VISUAL DIRECTIVE",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { viewModel.onImageGenPromptChanged(it) },
                        placeholder = { Text("A futuristic cybernetic tiger inside neon landscape...", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFBF5AF2),
                            unfocusedBorderColor = Color(0x3F00D2FF),
                            focusedContainerColor = Color(0xFF070518),
                            unfocusedContainerColor = Color(0xFF070518)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "ARTISTIC THEMATIC STYLE",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // LazyRow style selector pills
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(styles) { style ->
                            val isSelected = style == activeStyle
                            SuggestionChip(
                                onClick = { viewModel.onSharedStyleSelected(style) },
                                label = { Text(style, fontSize = 11.sp, color = if (isSelected) Color(0xFF03030F) else Color.White) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (isSelected) Color(0xFF00D2FF) else Color(0xFF070518)
                                ),
                                border = if (isSelected) null else BorderStroke(0.6.dp, Color(0x3F00D2FF))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generation Action Button
                    Button(
                        onClick = { viewModel.generateImage() },
                        enabled = prompt.isNotBlank() && !loading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00D2FF),
                            disabledContainerColor = Color(0xFF00D2FF).copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(color = Color(0xFF03030F), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Synthesizing Canvas...", color = Color(0xFF03030F), fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "", tint = Color(0xFF03030F))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Render Image Vectors", color = Color(0xFF03030F), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // active render area
            if (loading || base64Img != null) {
                Text(
                    text = "ACTIVE SYNTHESIS OUTPOST",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                    border = BorderStroke(1.dp, Color(0x3FBF5AF2))
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (loading) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = Color(0xFFBF5AF2), modifier = Modifier.size(45.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("Engaging Generative Diffusion Matrix...", color = Color.Gray, fontSize = 12.sp)
                            }
                        } else if (base64Img != null) {
                            if (base64Img!!.startsWith("ERROR:")) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                                    Icon(Icons.Default.Error, contentDescription = "", tint = Color.Red, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Rendering error / Limit reached. Please enter a valid prompt and retry.",
                                        color = Color.Gray,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                val bitmap = base64ToBitmap(base64Img!!)
                                if (bitmap != null) {
                                    Image(
                                        bitmap = bitmap.asImageBitmap(),
                                        contentDescription = "Active generated image",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clickable { expandedBase64Img = base64Img }
                                    )
                                } else {
                                    Text("Image parsing crashed.", color = Color.Red)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(28.dp))
            }

            // Historical gallery of results
            if (galleryImages.isNotEmpty()) {
                Text(
                    text = "HISTORICAL IMAGE GALLERY",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(galleryImages) { entry ->
                        val bmp = base64ToBitmap(entry.base64Data)
                        if (bmp != null) {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .size(100.dp)
                                    .clickable { expandedBase64Img = entry.base64Data }
                            ) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = entry.prompt,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Expanded full-screen preview lightbox overlay
        if (expandedBase64Img != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { expandedBase64Img = null },
                contentAlignment = Alignment.Center
            ) {
                val fullBmp = base64ToBitmap(expandedBase64Img!!)
                if (fullBmp != null) {
                    Image(
                        bitmap = fullBmp.asImageBitmap(),
                        contentDescription = "Expanded visual preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                IconButton(
                    onClick = { expandedBase64Img = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(24.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close preview", tint = Color.White)
                }
            }
        }
    }
}

// Helper utility: Base64 decode to Bitmap
fun base64ToBitmap(base64Str: String): Bitmap? {
    return try {
        val decodedBytes = Base64.decode(base64Str, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
    } catch (e: Exception) {
        null
    }
}
