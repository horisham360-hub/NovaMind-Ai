package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val LightPrimary = Color(0xFF5A20FF)
val LightSecondary = Color(0xFF9E00FF)
val LightTertiary = Color(0xFF00A2FF)
val LightBackground = Color(0xFFF7F8FF)
val LightSurface = Color(0xFFFFFFFF)
val OnLightBackground = Color(0xFF08061F)

// Dark Colors (The "Cosmic Slate" Master Theme)
val DarkPrimary = Color(0xFF00D2FF)      // Electric Glow Blue
val DarkSecondary = Color(0xFFBF5AF2)    // Glowing Velvet Purple
val DarkTertiary = Color(0xFF00FFCC)     // Tech Mint
val DarkBackground = Color(0xFF060515)   // Space Void Black
val DarkSurface = Color(0xFF13112E)      // Deep Fleet Navy
val OnDarkBackground = Color(0xFFE2E4F2) // Soft Pearl Gray
val AccentGlow = Color(0xFF2E1668)       // Deep Purple Shadow Accent
