package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.ui.platform.LocalContext
import java.util.Locale
import com.example.data.database.ChatMessageEntity
import com.example.data.database.ChatThreadEntity
import com.example.ui.viewmodel.NovaMindViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: NovaMindViewModel) {
    val threads by viewModel.allThreads.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val currentThreadId by viewModel.currentThreadId.collectAsState()
    val chatInput by viewModel.chatInput.collectAsState()
    val chatLoading by viewModel.chatLoading.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Slide up/down bottom sheets to switch or manage chat threads
    var showThreadSelector by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val isListening = remember { mutableStateOf(false) }

    val hasRecordAudioPermission = remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasRecordAudioPermission.value = isGranted
    }

    val speechRecognizer = remember { SpeechRecognizer.createSpeechRecognizer(context) }
    
    val recognitionListener = remember {
        object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening.value = true
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening.value = false
            }
            override fun onError(error: Int) {
                isListening.value = false
            }
            override fun onResults(results: Bundle?) {
                isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val textSpoken = matches?.firstOrNull() ?: ""
                if (textSpoken.isNotBlank()) {
                    viewModel.onChatInputChanged(textSpoken)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partialText = matches?.firstOrNull() ?: ""
                if (partialText.isNotBlank()) {
                    viewModel.onChatInputChanged(partialText)
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    LaunchedEffect(speechRecognizer) {
        speechRecognizer.setRecognitionListener(recognitionListener)
    }

    DisposableEffect(Unit) {
        onDispose {
            speechRecognizer.destroy()
        }
    }

    // Scroll automatically when new messages appear
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Screen Sub-Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF13112E))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showThreadSelector = true }) {
                        Icon(
                            imageVector = Icons.Default.MenuOpen,
                            contentDescription = "Threads List",
                            tint = Color(0xFF00D2FF)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (currentThreadId != null) {
                                threads.find { it.id == currentThreadId }?.title ?: "Chat Stream"
                            } else {
                                "New Cognitive session"
                            },
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = "Model: gemini-3.5-flash",
                            color = Color(0xFFBF5AF2),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Light
                        )
                    }
                }

                // Action to quick discard thread or clear chat
                if (currentThreadId != null) {
                    IconButton(onClick = { viewModel.deleteThreadById(currentThreadId!!) }) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Drop session",
                            tint = Color.Gray
                        )
                    }
                }
            }

            // Main chat layout or empty state welcome flow
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (currentThreadId == null) {
                    // Empty Start layout with sample prompt suggest triggers
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Assalamualaikum, ${settings.username}!",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "NovaMind is calibrated and ready to communicate.",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(bottom = 24.dp)
                            )

                            // Suggestion starter tags
                            Text(
                                text = "Suggested Starters:",
                                color = Color(0xFF00D2FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.align(Alignment.Start).padding(bottom = 8.dp)
                            )

                            val starters = listOf(
                                "Explain astrophysics to a 10yo",
                                "Write a beautiful greeting in Arabic",
                                "Suggest tech startup logos design ideas",
                                "How do neural architectures function?"
                            )

                            starters.forEach { suggestion ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E).copy(alpha = 0.6f)),
                                    border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable {
                                            viewModel.startNewThread(suggestion) { id ->
                                                viewModel.sendMessage(suggestion)
                                            }
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lightbulb,
                                            contentDescription = "Suggestion",
                                            tint = Color(0xFFFFCC00),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = suggestion,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // List of messages
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        itemsIndexed(messages) { index, message ->
                            val isLast = index == messages.size - 1
                            ChatBubble(message = message, isLast = isLast)
                        }

                        if (chatLoading) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .background(Color(0xFF13112E), RoundedCornerShape(16.dp))
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = Color(0xFF00D2FF),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = "Synthesizing intelligence...",
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Input panel at bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A081C))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatInput,
                        onValueChange = { viewModel.onChatInputChanged(it) },
                        placeholder = { 
                            Text(
                                text = if (isListening.value) "Listening..." else "Fulfill input coordinates...", 
                                color = if (isListening.value) Color(0xFF00D2FF) else Color.Gray, 
                                fontSize = 14.sp
                            ) 
                        },
                        leadingIcon = {
                            val isRecordingActive = isListening.value
                            IconButton(
                                onClick = {
                                    if (isRecordingActive) {
                                        try {
                                            speechRecognizer.stopListening()
                                        } catch (e: Exception) {}
                                        isListening.value = false
                                    } else {
                                        if (!hasRecordAudioPermission.value) {
                                            permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                        } else {
                                            try {
                                                isListening.value = true
                                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                                                }
                                                speechRecognizer.startListening(intent)
                                            } catch (e: Exception) {
                                                isListening.value = false
                                            }
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice Input",
                                    tint = if (isRecordingActive) Color(0xFFBF5AF2) else Color(0xFF00D2FF)
                                )
                            }
                        },
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp),
                        maxLines = 4,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00D2FF),
                            unfocusedBorderColor = Color(0x3F00D2FF),
                            focusedContainerColor = Color(0xFF03030F),
                            unfocusedContainerColor = Color(0xFF03030F)
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    IconButton(
                        onClick = {
                            if (chatInput.isNotBlank()) {
                                if (currentThreadId == null) {
                                    viewModel.startNewThread(chatInput) { id ->
                                        viewModel.sendMessage(chatInput)
                                    }
                                } else {
                                    viewModel.sendMessage(chatInput)
                                }
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFF00D2FF), Color(0xFF5A20FF))
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Transmit",
                            tint = Color(0xFF03030F),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Thread selector sliding bottom panel drawer custom overlay
        if (showThreadSelector) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable { showThreadSelector = false }
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.75f)
                        .align(Alignment.BottomCenter)
                        .clickable(enabled = false) {}
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Cognitive Sessions",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { showThreadSelector = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                            }
                        }

                        // Spark a new thread trigger
                        Button(
                            onClick = {
                                viewModel.selectThread(null)
                                showThreadSelector = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 14.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "", tint = Color(0xFF03030F))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Spark New Thread", color = Color(0xFF03030F), fontWeight = FontWeight.Bold)
                        }

                        if (threads.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No stored sessions. Spark one above!",
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 13.sp
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            ) {
                                items(threads) { thread ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (thread.id == currentThreadId) Color(0xFF03030F) else Color.Unspecified
                                            )
                                            .clickable {
                                                viewModel.selectThread(thread.id)
                                                showThreadSelector = false
                                            }
                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ChatBubble,
                                                contentDescription = "",
                                                tint = if (thread.id == currentThreadId) Color(0xFF00D2FF) else Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = thread.title,
                                                color = if (thread.id == currentThreadId) Color.White else Color.White.copy(alpha = 0.8f),
                                                fontSize = 13.sp,
                                                fontWeight = if (thread.id == currentThreadId) FontWeight.Bold else FontWeight.Normal,
                                                maxLines = 1
                                            )
                                        }

                                        IconButton(onClick = { viewModel.deleteThreadById(thread.id) }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Drop session",
                                                tint = Color.Red.copy(alpha = 0.6f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessageEntity, isLast: Boolean = false) {
    val isUser = message.role == "user"
    val bubbleColor = if (isUser) Color(0xFF00D2FF) else Color(0xFF13112E)
    val textColor = if (isUser) Color(0xFF03030F) else Color.White

    // Only run typing animation for newly-created model messages (last message and less than 5 seconds old)
    val isNewModelMessage = !isUser && isLast && (System.currentTimeMillis() - message.timestamp < 5000)

    var displayedText by remember(message.id, message.content) {
        mutableStateOf(if (isNewModelMessage) "" else message.content)
    }

    var isTypingComplete by remember(message.id, message.content) {
        mutableStateOf(!isNewModelMessage)
    }

    if (isNewModelMessage && !isTypingComplete) {
        LaunchedEffect(message.content) {
            val text = message.content
            val charsToType = text.length
            if (charsToType > 0) {
                // If the message is very long, speed up typing so it doesn't take forever
                val baseDelay = when {
                    charsToType > 500 -> 3L
                    charsToType > 200 -> 6L
                    else -> 12L
                }
                for (i in 1..charsToType) {
                    if (isTypingComplete) break
                    displayedText = text.substring(0, i)
                    delay(baseDelay)
                }
            }
            isTypingComplete = true
            displayedText = text
        }
    } else {
        displayedText = message.content
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            border = if (!isUser) BorderStroke(0.6.dp, Color(0x3F00D2FF)) else null,
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clickable(enabled = !isTypingComplete) {
                    isTypingComplete = true
                    displayedText = message.content
                }
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Header of sender label
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "Transmitted Coordinates" else "NovaMind Engine",
                        color = if (isUser) Color(0xFF03030F).copy(alpha = 0.7f) else Color(0xFFBF5AF2),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    if (!isTypingComplete && !isUser) {
                        Text(
                            text = "Synthesizing... (Tap to skip)",
                            color = Color(0xFF00D2FF).copy(alpha = 0.7f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Normal,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }

                // Message Text
                Text(
                    text = displayedText,
                    color = textColor,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}
