package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.*
import com.example.data.repository.NovaMindRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NovaMindViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = NovaMindRepository(application)

    // --- Configurations & Setup States ---
    val allThreads: StateFlow<List<ChatThreadEntity>> = repository.allThreads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGeneratedImages: StateFlow<List<GeneratedImageEntity>> = repository.allImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchHistory: StateFlow<List<SearchHistoryEntity>> = repository.searchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettingsEntity> = repository.userSettings
        .map { it ?: UserSettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettingsEntity())

    // --- Flow-based Dynamic UI Messages ---
    private val _currentThreadId = MutableStateFlow<Int?>(null)
    val currentThreadId: StateFlow<Int?> = _currentThreadId.asStateFlow()

    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentThreadId
        .flatMapLatest { threadId ->
            if (threadId != null) {
                repository.getMessagesForThread(threadId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Screen States --
    // Text generations states
    private val _chatLoading = MutableStateFlow(false)
    val chatLoading: StateFlow<Boolean> = _chatLoading.asStateFlow()

    private val _chatInput = MutableStateFlow("")
    val chatInput: StateFlow<String> = _chatInput.asStateFlow()

    // Image generator states
    private val _imageGenLoading = MutableStateFlow(false)
    val imageGenLoading: StateFlow<Boolean> = _imageGenLoading.asStateFlow()

    private val _imageGenPrompt = MutableStateFlow("")
    val imageGenPrompt: StateFlow<String> = _imageGenPrompt.asStateFlow()

    private val _imageGenStyle = MutableStateFlow("Original")
    val imageGenStyle: StateFlow<String> = _imageGenStyle.asStateFlow()

    private val _generatedImageBase64 = MutableStateFlow<String?>(null)
    val generatedImageBase64: StateFlow<String?> = _generatedImageBase64.asStateFlow()

    // File upload/Analysis states
    private val _analysisLoading = MutableStateFlow(false)
    val analysisLoading: StateFlow<Boolean> = _analysisLoading.asStateFlow()

    private val _analysisResult = MutableStateFlow<String?>(null)
    val analysisResult: StateFlow<String?> = _analysisResult.asStateFlow()

    private val _analysisImage = MutableStateFlow<Bitmap?>(null)
    val analysisImage: StateFlow<Bitmap?> = _analysisImage.asStateFlow()

    private val _analysisFileText = MutableStateFlow<String?>(null)
    val analysisFileText: StateFlow<String?> = _analysisFileText.asStateFlow()

    // Voice States
    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()

    private val _voiceOutputSpoken = MutableStateFlow("")
    val voiceOutputSpoken: StateFlow<String> = _voiceOutputSpoken.asStateFlow()

    init {
        // Hydrate default user setting or perform check
        viewModelScope.launch {
            val s = repository.getSettingsDirect()
            // If setup is never finished, prepopulate settings
            if (!s.isSetupFinished) {
                repository.saveSettings(UserSettingsEntity(isSetupFinished = true))
            }
        }
    }

    // --- Actions ---

    fun onChatInputChanged(text: String) {
        _chatInput.value = text
    }

    fun onImageGenPromptChanged(text: String) {
        _imageGenPrompt.value = text
    }

    fun onSharedStyleSelected(style: String) {
        _imageGenStyle.value = style
    }

    fun selectThread(threadId: Int?) {
        _currentThreadId.value = threadId
    }

    fun updateUsername(name: String) = viewModelScope.launch {
        val current = settings.value
        repository.saveSettings(current.copy(username = name))
    }

    fun updateLanguage(lang: String) = viewModelScope.launch {
        val current = settings.value
        repository.saveSettings(current.copy(preferredLanguage = lang))
    }

    fun updateTheme(theme: String) = viewModelScope.launch {
        val current = settings.value
        repository.saveSettings(current.copy(themeMode = theme))
    }

    fun updateVoiceEnabled(enabled: Boolean) = viewModelScope.launch {
        val current = settings.value
        repository.saveSettings(current.copy(voiceOutputEnabled = enabled))
    }

    fun clearSearchHistory() = viewModelScope.launch {
        repository.clearHistory()
    }

    // --- Feature logic bindings ---

    fun startNewThread(prompt: String, callback: (Int) -> Unit) = viewModelScope.launch {
        _chatLoading.value = true
        val title = if (prompt.length > 25) prompt.take(25) + "..." else prompt
        val newId = repository.createThread(title)
        _currentThreadId.value = newId
        callback(newId)
    }

    fun sendMessage(text: String) = viewModelScope.launch {
        val threadId = _currentThreadId.value ?: return@launch
        if (text.isBlank()) return@launch

        _chatInput.value = ""
        _chatLoading.value = true

        // 1. Save user message
        val userMsg = ChatMessageEntity(threadId = threadId, role = "user", content = text)
        repository.saveMessage(userMsg)
        repository.saveSearch(text)

        // 2. Fetch history
        val history = currentMessages.value

        // Intercept creator questions with a specific predefined answer
        val cleanText = text.trim().lowercase().replace(Regex("[?.!]"), "").trim()
        val response = if (cleanText == "who built you" || 
            cleanText == "who created you" || 
            cleanText == "who made you"
        ) {
            "Assalamu Alaikum! 👋\n\nI was created and customized by Anas Ahmed. I am an AI assistant designed to help users with information, problem-solving, creativity, and everyday tasks.\n\nHow can I help you today?"
        } else {
            // 3. Generate Gemini response with robust fallback
            repository.generateChatResponse(prompt = text, history = history)
        }
        
        // 4. Save model response
        val modelMsg = ChatMessageEntity(threadId = threadId, role = "model", content = response)
        repository.saveMessage(modelMsg)

        _chatLoading.value = false
    }

    fun generateImage() = viewModelScope.launch {
        val prompt = _imageGenPrompt.value
        if (prompt.isBlank()) return@launch

        _imageGenLoading.value = true
        _generatedImageBase64.value = null

        // Translate and improve user's prompt first (AI image generation assistant behavior)
        val optimizedPrompt = repository.optimizeImagePrompt(prompt, _imageGenStyle.value)
        _imageGenPrompt.value = optimizedPrompt

        val result = repository.generateImageFromPrompt(optimizedPrompt, _imageGenStyle.value)
        if (result == "API_KEY_ERROR" || result == "NO_IMAGE_PART" || result.startsWith("ERROR:")) {
            _generatedImageBase64.value = "ERROR: $result"
        } else {
            _generatedImageBase64.value = result
            repository.saveSearch("Generate: $optimizedPrompt")
        }
        _imageGenLoading.value = false
    }

    fun deleteThreadById(threadId: Int) = viewModelScope.launch {
        repository.deleteThread(threadId)
        if (_currentThreadId.value == threadId) {
            _currentThreadId.value = null
        }
    }

    // --- Image Analysis & Analysis Actions ---

    fun setAnalysisImage(bitmap: Bitmap?) {
        _analysisImage.value = bitmap
        _analysisFileText.value = null
    }

    fun setAnalysisFileText(text: String?) {
        _analysisFileText.value = text
        _analysisImage.value = null
    }

    fun startAnalysis(prompt: String) = viewModelScope.launch {
        val image = _analysisImage.value
        val fileText = _analysisFileText.value

        if (image == null && fileText == null) return@launch

        _analysisLoading.value = true
        _analysisResult.value = ""

        if (image != null) {
            val resp = repository.analyzeImageWithResponse(prompt, image)
            _analysisResult.value = resp
            repository.saveSearch("Analyze Image: $prompt")
        } else if (fileText != null) {
            // Incorporate file text in prompt
            val fullPrompt = "I uploaded a document. Here is its content: \n$fileText\n\nQuestion / instruction about the document:\n$prompt"
            val resp = repository.generateChatResponse(fullPrompt, emptyList())
            _analysisResult.value = resp
            repository.saveSearch("Analyze File: $prompt")
        }

        _analysisLoading.value = false
    }

    // Sets recording voice mock toggle or speech bindings
    fun setRecordingVoice(recording: Boolean) {
        _isRecordingVoice.value = recording
    }
}
