package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AboutScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Logo Representational Frame
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color(0xFF13112E)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AcUnit,
                    contentDescription = "NovaMind Emblem",
                    tint = Color(0xFF00D2FF),
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "NovaMind AI",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Text(
                text = "Think Beyond Limits",
                color = Color(0xFF00D2FF),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )

            Text(
                text = "Created by Anas Ahmed",
                color = Color(0xFFBF5AF2),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // About Text Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "THE COGNITIVE PLATFORM",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Text(
                        text = "NovaMind AI is a state-of-the-art multi-dimensional machine intelligence suite, built to integrate deep conversational reasoning, localized voice synthesis, real-time computer vision document transcription, and hyper-fidelity text-to-image synthesis into a unified premium mobile experience.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            // Specs Table Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                border = BorderStroke(1.dp, Color(0x1F00D2FF)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "TELEMETRY SPECIFICATIONS",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    val specs = listOf(
                        "App Core Version" to "v2.6.4 (Production Build)",
                        "Primary Large Language Model" to "gemini-3.5-flash",
                        "Primary Image Synthesis Model" to "gemini-2.5-flash-image",
                        "Database Core" to "SQLite Abstracted Room Core",
                        "Interface Engine" to "Jetpack Compose Declarative M3",
                        "Global Translations" to "Active (English, Arabic, Hindi...)"
                    )

                    specs.forEachIndexed { idx, pair ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pair.first, color = Color.Gray, fontSize = 12.sp)
                            Text(pair.second, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        if (idx < specs.size - 1) {
                            Divider(color = Color.White.copy(alpha = 0.05f))
                        }
                    }
                }
            }

            // Legal Disclaimer / Quote Statement
            Text(
                text = "NovaMind AI is built offline-first and prioritizes user credentials security. Developed entirely in Kotlin and Compose.",
                color = Color.Gray,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp,
                modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 40.dp)
            )
        }
    }
}
