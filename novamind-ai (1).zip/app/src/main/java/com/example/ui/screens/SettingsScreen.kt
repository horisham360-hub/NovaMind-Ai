package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.UserSettingsEntity
import com.example.ui.viewmodel.NovaMindViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: NovaMindViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()

    var username by remember { mutableStateOf("") }
    var userLanguage by remember { mutableStateOf("") }
    var voiceEnabled by remember { mutableStateOf(true) }
    var feedbackText by remember { mutableStateOf("") }

    // Dropdown expanded tracker
    val languages = listOf("English", "Hindi", "Urdu", "Arabic", "Marathi")
    var langExpanded by remember { mutableStateOf(false) }

    // Sync input components when Room settings data hydrates
    LaunchedEffect(settings) {
        username = settings.username
        userLanguage = settings.preferredLanguage
        voiceEnabled = settings.voiceOutputEnabled
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "Control Terminal",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Adjust telemetry preferences and configure system behaviors",
                color = Color(0xFF00D2FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            // User Identity Segment
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "COGNITIVE IDENTITY IDENTIFIER",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            viewModel.updateUsername(it)
                        },
                        leadingIcon = { Icon(Icons.Default.Tune, contentDescription = "", tint = Color(0xFF00D2FF)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFBF5AF2),
                            unfocusedBorderColor = Color(0x3F00D2FF),
                            focusedContainerColor = Color(0xFF070518),
                            unfocusedContainerColor = Color(0xFF070518)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp)
                    )
                }
            }

            // Global preferences segment
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1F00D2FF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SYSTEM PREFERENCES",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // Language Selector Dropdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("System Language", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Default response translation language", color = Color.Gray, fontSize = 11.sp)
                        }

                        ExposedDropdownMenuBox(
                            expanded = langExpanded,
                            onExpandedChange = { langExpanded = !langExpanded }
                        ) {
                            OutlinedTextField(
                                value = userLanguage,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = langExpanded) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFF070518),
                                    unfocusedContainerColor = Color(0xFF070518),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .width(130.dp)
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = langExpanded,
                                onDismissRequest = { langExpanded = false }
                            ) {
                                languages.forEach { language ->
                                    DropdownMenuItem(
                                        text = { Text(language) },
                                        onClick = {
                                            userLanguage = language
                                            viewModel.updateLanguage(language)
                                            langExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Voice output toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Audio Synthesis Output", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Speak generated voice vectors aloud", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = voiceEnabled,
                            onCheckedChange = {
                                voiceEnabled = it
                                viewModel.updateVoiceEnabled(it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00D2FF),
                                checkedTrackColor = Color(0xFFBF5AF2)
                            )
                        )
                    }
                }
            }

            // Utilities Logs cleaning segment
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1F00D2FF)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DATA MANAGEMENT",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Button(
                        onClick = {
                            viewModel.clearSearchHistory()
                            Toast.makeText(context, "Search telemetry successfully wiped.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B30)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Purge Search logs", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated trigger notification test
                    Button(
                        onClick = {
                            Toast.makeText(context, "NovaMind notifications calibrated and verified!", Toast.LENGTH_LONG).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF13112E)),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = "", tint = Color(0xFF00D2FF))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Notification Channel", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Feedback Segment
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0x1F00D2FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FEEDBACK CHIP TRANSMITTER",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text("Enter suggestions to improve cognitive core...", color = Color.Gray, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFBF5AF2),
                            unfocusedBorderColor = Color(0x3F00D2FF),
                            focusedContainerColor = Color(0xFF070518),
                            unfocusedContainerColor = Color(0xFF070518)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 13.sp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (feedbackText.isNotBlank()) {
                                Toast.makeText(context, "Feedback securely transmitted. Shukran!", Toast.LENGTH_SHORT).show()
                                feedbackText = ""
                            }
                        },
                        enabled = feedbackText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Feedback, contentDescription = "", tint = Color(0xFF03030F))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Transmit Feedback", color = Color(0xFF03030F), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
