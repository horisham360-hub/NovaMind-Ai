package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.NovaMindViewModel

enum class DashboardTab(val title: String, val icon: ImageVector) {
    CHAT("Chat", Icons.Default.Chat),
    VOICE("Voice", Icons.Default.Mic),
    IMAGE_GEN("Image", Icons.Default.AutoAwesome),
    ANALYSIS("Analysis", Icons.Default.HourglassEmpty),
    SETTINGS("Settings", Icons.Default.Settings),
    ABOUT("About", Icons.Default.Info)
}

@Composable
fun MainDashboard(
    viewModel: NovaMindViewModel,
    onLogout: () -> Unit
) {
    var activeTab by remember { mutableStateOf(DashboardTab.CHAT) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF13112E),
                windowInsets = WindowInsets.navigationBars,
                tonalElevation = 8.dp
            ) {
                DashboardTab.values().forEach { tab ->
                    val isSelected = tab == activeTab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { activeTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) Color(0xFF03030F) else Color.Gray
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                color = if (isSelected) Color(0xFF00D2FF) else Color.Gray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFF00D2FF)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF03030F))
        ) {
            when (activeTab) {
                DashboardTab.CHAT -> ChatScreen(viewModel = viewModel)
                DashboardTab.VOICE -> VoiceScreen(viewModel = viewModel)
                DashboardTab.IMAGE_GEN -> ImageGenScreen(viewModel = viewModel)
                DashboardTab.ANALYSIS -> ImageAnalysisScreen(viewModel = viewModel)
                DashboardTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                DashboardTab.ABOUT -> AboutScreen()
            }
        }
    }
}
