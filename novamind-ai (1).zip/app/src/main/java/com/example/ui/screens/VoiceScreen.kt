package com.example.ui.screens

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.launch
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.NovaMindViewModel
import java.util.*

@Composable
fun VoiceScreen(viewModel: NovaMindViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isRecording by viewModel.isRecordingVoice.collectAsState()
    val speechInputText = remember { mutableStateOf("Ready to capture voice vectors...") }
    val assistantVoiceResponse = remember { mutableStateOf("") }
    val modelLoading = remember { mutableStateOf(false) }

    // TextToSpeech holder
    var tts: TextToSpeech? by remember { mutableStateOf(null) }

    // Init Android TextToSpeech securely inside composable life-cycle
    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    // SpeechRecognizer binder
    val speechRecognizer = remember { SpeechRecognizer.createSpeechRecognizer(context) }
    val recognizerIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
    }

    val recognitionListener = remember {
        object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                speechInputText.value = "Listening to voice input..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                viewModel.setRecordingVoice(false)
                speechInputText.value = "Analyzing capture..."
            }
            override fun onError(error: Int) {
                viewModel.setRecordingVoice(false)
                speechInputText.value = "No audio detected. Please tap mic and speak again."
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val textSpoken = matches?.firstOrNull() ?: ""
                if (textSpoken.isNotBlank()) {
                    speechInputText.value = "\"$textSpoken\""
                    // Execute pipeline query Gemini
                    modelLoading.value = true
                    coroutineScope.launch {
                        val response = com.example.data.repository.NovaMindRepository(context)
                            .generateChatResponse(
                                prompt = "Analyze and answer this voice directive elegantly in under 2 sentences: $textSpoken",
                                history = emptyList()
                            )
                        assistantVoiceResponse.value = response
                        modelLoading.value = false
                        // Trigger TTS playback if checked in settings
                        val isTtsEnabled = viewModel.settings.value.voiceOutputEnabled
                        if (isTtsEnabled) {
                            tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, null)
                        }
                    }
                } else {
                    speechInputText.value = "Failed to transcribe voice."
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    LaunchedEffect(speechRecognizer) {
        speechRecognizer.setRecognitionListener(recognitionListener)
    }

    // Animation scales for the glowing visual radar
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRecording) 1.5f else 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "radar"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03030F)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Voice Assistant",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Real-time Natural Speech Interface",
                color = Color(0xFF00D2FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp, bottom = 48.dp)
            )

            // Dynamic pulsating radar & microphone center
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isRecording) {
                                listOf(Color(0xFFBF5AF2).copy(alpha = 0.4f), Color(0x00000000))
                            } else {
                                listOf(Color(0xFF00D2FF).copy(alpha = 0.2f), Color(0x00000000))
                            }
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = if (isRecording) {
                                    listOf(Color(0xFFBF5AF2), Color(0xFFE2E4F2))
                                } else {
                                    listOf(Color(0xFF00D2FF), Color(0xFF5A20FF))
                                }
                            )
                        )
                        .clickable {
                            if (isRecording) {
                                speechRecognizer.cancel()
                                viewModel.setRecordingVoice(false)
                                speechInputText.value = "Voice trace canceled."
                            } else {
                                viewModel.setRecordingVoice(true)
                                assistantVoiceResponse.value = ""
                                speechRecognizer.startListening(recognizerIntent)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Trigger Speech",
                        tint = if (isRecording) Color.White else Color(0xFF03030F),
                        modifier = Modifier.size(45.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(60.dp))

            // User Spoken Transcript Card Area
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13112E)),
                border = BorderStroke(1.dp, Color(0x3F00D2FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "CAPUTRED TRANSCRIPT:",
                        color = Color(0xFF00D2FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = speechInputText.value,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Assistant Response Display area
            if (modelLoading.value) {
                CircularProgressIndicator(color = Color(0xFFBF5AF2), modifier = Modifier.size(24.dp))
            } else if (assistantVoiceResponse.value.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1668).copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0x3FBF5AF2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Voice",
                            tint = Color(0xFFBF5AF2),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = assistantVoiceResponse.value,
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
